<html>
<head>
    <link type="text/css" rel="stylesheet" charset="UTF-8" href="style.css">
</head>
<body>
<div class="content">
<form action="userLogin.php" method="post">
    <div class="cont">
        <h1>Prijava</h1>
        <hr>
        <label for="uname"><b>Korisničko ime</b></label>
        <input type="text" placeholder="Unesite korisničko ime" name="uname" required>

        <label for="password"><b>Lozinka</b></label>
        <input type="password" placeholder="Unesite Lozinka" name="password" required>

        <input type="submit" value="Prijava" class="btnLogin">
    </div>


</form>
</div>

</body>
</html>
