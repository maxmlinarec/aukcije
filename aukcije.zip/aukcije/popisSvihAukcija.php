<section>
    <h2>Popis svih aukcija</h2>

    <table>
        <tr>
            <th>Aukcija</th>
            <th>Opis</th>
            <th>Datum početka</th>
            <th>Datum završetka</th>
        </tr>
        <?php showPopisSvihAukcija($con);?>
    </table>
</section>