<section>
    <h2>Otvorene aukcije</h2>

    <table>
        <?php showOtvoreneAukcije($con);?>
    </table>
</section>