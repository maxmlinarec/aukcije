<?php
$con = mysqli_connect('127.0.0.1', 'root', 'SQLsifra123$', 'aukcija');



if (mysqli_connect_errno()){
    exit("Greška kod spajanja na bazu. Greška: " . mysqli_connect_error());
}

mysqli_set_charset($con, 'UTF8');