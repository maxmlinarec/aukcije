<?php
include 'connect.php';

include_once 'common.php';

checkInputParams([
    'id' => 'integer'
], true);

$id = $_POST['id'];
$name = $_POST['name'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$email = $_POST['email'];
$lozinka = $_POST['lozinka'];
$ponovljena_lozinka = $_POST['ponovljena_lozinka'];
$img = $_POST['img'];
if(isset($_POST['tip'])){$tip = 2;}else{$tip = 3;}

$sql = "select * from korisnik where korisnicko_ime='" . $username . "' and korisnik_id <> $id";

$res = mysqli_query($con, $sql);

if (mysqli_num_rows($res) > 0){
    redirectToIndex('Korisnik već postoji', 'korisnici.php');
}

$sql = "select * from korisnik where korisnik_id=$id";

$res = mysqli_query($con, $sql);

$korisnik = mysqli_fetch_assoc($res);

if ($korisnik === null){
    redirectToIndex('Korisnik ne postoji', 'korisnici.php');
}

if ($lozinka == $ponovljena_lozinka){
    $sql = "UPDATE `korisnik` SET lozinka ='" . $lozinka . "', `korisnicko_ime`='" . $username . "',`ime`='" . $name . "',`prezime`='" . $lastname . "',`email`='" . $email . "', `slika` = '" . $img . "', `tip_id` =".$tip." WHERE `korisnik_id` =" . $id;
    if (!mysqli_query($con, $sql)) {
        echo "Error updating record: " . mysqli_error($con);
        die();
    }
}
echo("<script>location.href = 'korisnici.php';</script>");
die();