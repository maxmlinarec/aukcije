<?php

include 'connect.php';
include_once 'common.php';



checkInputParams([
    'name' => 'str',
    'lastname' => 'str',
    'username' => 'str',
    'email' => 'str',
    'img' => 'str'
], true);

$name = $_POST['name'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$img = $_POST['img'];
if(isset($_POST['tip'])){$tip = 2;}else{$tip = 3;}

$sql = "select * from korisnik where korisnicko_ime='" . $username . "'";

$res = mysqli_query($con, $sql);

if (mysqli_num_rows($res) > 0){
    redirectToIndex('Korisnik već postoji', 'korisnici.php');
}

$sql = "INSERT INTO `korisnik`(`tip_id`,`korisnicko_ime`, `lozinka`, `ime`, `prezime`, `email`, `slika`) VALUES (".$tip.",'".$username."','".$password."','".$name."','".$lastname."','".$email."','".$img."')";

if (!mysqli_query($con, $sql)) {
    echo "Error updating record: " . mysqli_error($con);
    die();
}
echo("<script>location.href = 'korisnici.php';</script>");
die();