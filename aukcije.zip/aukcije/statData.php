<?php
include 'connect.php';
function getStats($con,$dv_p,$dv_z)
{

    $sql = "select a.naziv, count(distinct p.korisnik_id) as broj_prodavaca, count(distinct po.korisnik_id) broj_kupaca from aukcija a left join predmet p on a.aukcija_id=p.aukcija_id left join ponuda po on po.predmet_id=p.predmet_id where a.datum_vrijeme_zavrsetka is not null and a.datum_vrijeme_zavrsetka < now()  and a.datum_vrijeme_pocetka between STR_TO_DATE('" . $dv_p . "','%Y-%m-%d %H:%i:%s') and STR_TO_DATE('" . $dv_z . "','%Y-%m-%d %H:%i:%s') group by a.aukcija_id";
    $result = mysqli_query($con, $sql);
    $stat = [];
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $stat[] = array(
            "broj_kupaca" => $row['broj_kupaca'],
            "naziv" => $row['naziv'],
            'broj_prodavaca' => $row['broj_prodavaca']
        );
    }
    mysqli_free_result($result);
    return $stat;
}
function getStats2($con,$dv_p,$dv_z)
{
    $sql = "select a.naziv, count(distinct p.korisnik_id) broj_prodavaca from aukcija a left join predmet p on a.aukcija_id=p.aukcija_id  where a.datum_vrijeme_zavrsetka is not null and a.datum_vrijeme_zavrsetka < now()  and a.datum_vrijeme_pocetka between STR_TO_DATE('" . $dv_p . "','%Y-%m-%d %H:%i:%s') and STR_TO_DATE('" . $dv_z . "','%Y-%m-%d %H:%i:%s') group by a.aukcija_id";
    $result = mysqli_query($con, $sql);
    $stat = false;
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $stat[] = array(
            "naziv" => $row['naziv'],
            "broj_prodavaca" => $row['broj_prodavaca'],
        );
    }
    mysqli_free_result($result);
    return $stat;
}

function showStats($con,$dv_p,$dv_z)
{
    $stat = getStats($con,$dv_p,$dv_z);
    if (!empty($stat)) {
        echo '<table>';
        echo '<tr>' .
            '<th>Aukcija</th>' .
            '<th>Broj prodavača</th>' .
            '<th>Broj kupaca</th>' .
            '</tr>';
        for ($i = 0; $i < count($stat); $i++) {
            echo "<tr>";
            echo "<td>", $stat[$i]['naziv'], "</td>";
            echo "<td>", $stat[$i]['broj_prodavaca'], "</td>";
            echo "<td>", $stat[$i]['broj_kupaca'], "</td>";
            echo "</tr>";
        }
        echo '</table>';
    } else {
        echo '<table>';
        echo "<tr>";
        echo "<td>Trenutno nema podataka.</td>";
        echo "</tr>";
        echo '</table>';
    }
    
}

