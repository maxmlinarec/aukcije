INSERT INTO `tip_korisnika` (`tip_id`, `naziv`) VALUES
(1, 'administrator'),
(2, 'voditelj'),
(3, 'korisnik');

INSERT INTO `korisnik` (`korisnik_id`, `tip_id`, `korisnicko_ime`, `lozinka`, `ime`, `prezime`, `email`, `slika`) VALUES
(1, 1, 'admin', 'tvz', 'Administrator', '', '', 'korisnici/admin.jpeg'),
(2, 2, 'moderator', '123456', 'Moderator', '', '', 'korisnici/moderator.jpg'),
(3, 3, 'kbencic', '123456', 'Karlo', 'Bencic', 'kbencic1@tvz.hr', 'korisnici/kbencic.png'),
(4, 3, 'mmlinarec', '123456', 'Max', 'Mlinarec', 'mmlinarec@tvz.hr', 'korisnici/mmlinarec.png'),
(5, 3, 'tteic', '123456', 'Tea', 'Teic', 'tteic@tvz.hr', 'korisnici/1.jpg'),
(6, 3, 'ddoric', '123456', 'Dora', 'Doric', 'ddoric@tvz.hr', 'korisnici/2.jpg'),
(7, 3, 'vvjekic', '123456', 'Vjeko', 'Vjekic', 'vvjekic@tvz.hr', 'korisnici/3.jpg'),
(8, 3, 'ttonic', '123456', 'Toni', 'Tonic', 'ttonic@tvz.hr', 'korisnici/4.jpg'),
(9, 3, 'aanic', '123456', 'Ana', 'Anic', 'aanic@tvz.hr', 'korisnici/5.jpg'),
(10, 3, 'kkarlic', '123456', 'Karlo', 'Karlic', 'kkarlic@tvz.hr', 'korisnici/6.jpg'),
(11, 3, 'hhrvojic', '123456', 'Hrvoje', 'Hrvojic', 'hhrvojic@tvz.hr', 'korisnici/7.jpg'),
(12, 3, 'vvlatkic', '123456', 'Vlatko', 'Vlatkic', 'vvlatkic@tvz.hr', 'korisnici/8.jpg'),
(13, 3, 'eemic', '123456', 'Ema', 'Emic', 'eemic@tvz.hr', 'korisnici/9.jpg'),
(14, 3, 'jjelenic', '123456', 'Jelena', 'Jeleneic', 'jjelenic@tvz.hr', 'korisnici/10.jpg'),
(15, 3, 'ttomic', '123456', 'Tomo', 'Tomic', 'ttomic@tvz.hr', 'korisnici/11.jpg'),
(16, 3, 'sstjepic', '123456', 'Stjepan', 'Stjepic', 'sstepic@tvz.hr', 'korisnici/12.jpg'),
(17, 3, 'iivic', '123456', 'Iva', 'Ivic', 'iivic@tvz.hr', 'korisnici/13.jpg'),
(18, 3, 'llukic', '123456', 'Luka', 'Lukic', 'llukic@tvz.hr', 'korisnici/14.jpg'),
(19, 3, 'mmarkic', '123456', 'Marko', 'Markic', 'mmarkic@tvz.hr', 'korisnici/15.jpg'),
(20, 3, 'pperic', '123456', 'Pero', 'Peric', 'pperic@tvz.hr', 'korisnici/16.jpg'),
(21, 3, 'ttaric', '123456', 'Tara', 'Taric', 'ttaric@tvz.hr', 'korisnici/17.jpg');

INSERT INTO `aukcija` (`aukcija_id`, `moderator_id`, `naziv`, `opis`, `datum_vrijeme_pocetka`, `datum_vrijeme_zavrsetka`) VALUES
(1, 2, 'Automobili', 'Aukcija novih i rabljenih osobnih automobila u Hrvatskoj i regiji.', '2022-07-01 11:55:00', '2022-07-15 23:55:00'),
(2, 2, 'Mobiteli', 'Aukcija mobitela, opreme za mobitele i dijelova za mobitel.', '2022-07-02 11:55:00', '2022-07-12 23:55:00'),
(3, 2, 'Od glave do pete ', 'Aukcija odjeće, obuće i modnih dodataka.', '2022-07-02 11:55:00', '2022-07-13 23:55:00');

INSERT INTO `predmet` (`predmet_id`, `aukcija_id`, `korisnik_id`, `naziv`, `opis`, `slika`, `pocetna_cijena`) VALUES
(1, 1, 4, 'BMW M5', 
'Marka automobila: Mercedes-Benz. 
Model automobila: M5. 
Tip automobila: 3.0 twin turbo 
Godina proizvodnje: 2020. 
Prijeđeni kilometri: 50000 km.
Motor: benzin. 
Snaga motora: 353 kW - 480 konja. 
Radni obujam: 2999 cm3. 
Mjenjač: automatski. 
Stanje: rabljeno.
Ostalo: Uredno servisiran i garažiran.
', 'https://ip.index.hr/remote/bucket.index.hr/b/index/951ee2ed-215d-4a8e-bfce-63fc184861e8.png?width=854&height=443&mode=crop&anchor=topcenter&scale=both', 400000),
(2, 1, 4, 'Mercedes-Benz C-klasa', 
'Marka automobila: Mercedes-Benz.
Model automobila: C-klasa.
Tip automobila: 220D.
Godina proizvodnje: 2021. godište.
Prijeđeni kilometri: 25361 km.
Motor: diesel.
Snaga motora: 147 kW - 200 konja.
Radni obujam: 1999 cm3.
Mjenjač: Automatski.
Stanje: rabljeno.
Ostalo: Uredno servisiran i garažiran.
', 'https://carwow-uk-wp-0.imgix.net/mercedes-c-class-revealed-front-1-lead.jpg?auto=format&cs=tinysrgb&fit=clip&ixlib=rb-1.1.0&q=10&w=800', 172000),
(3, 1, 4, 'Opel Insignia', 
'Marka automobila: Opel. 
Model automobila: Insignia. 
Tip automobila: 1,7. 
Godina proizvodnje: 2016. 
Prijeđeni kilometri: 90300 km.
Gorivo: diesel. 
Snaga motora: 104 kW. 
Radni obujam: 1699 cm3. 
Mjenjač: mehanički. 
Stanje: rabljeno.
Ostalo: Uredno servisiran i garažiran.
', 'https://www.autonadlanu.com/wp-content/uploads/2015/12/Opel-Insignia-2016.jpg', 90000),
(4, 1, 4, 'VW Golf VII', 'Marka automobila: VW. 
Model automobila: Golf VII. 
Tip automobila: 2,0 TSI. 
Godina proizvodnje: 2013. 
Prijeđeni kilometri: 220000 km.
Gorivo: benzin. 
Snaga motora: 150 kW. 
Radni obujam: 1986 cm3. 
Mjenjač: automatski. 
Stanje: rabljeno.
Ostalo: Uredno servisiran i garažiran.
', 'https://i0.wp.com/automania.hr/wp-content/uploads/2016/11/0__clanak-prva-8.jpg?w=1200&ssl=1', 70000),
(5, 1, 4, 'Smart', 'Marka automobila: Smart. 
Model automobila: Fortwo Coupe. 
Tip automobila: CDI. 
Godina proizvodnje: 2002. 
Prijeđeni kilometri: 323000 km.
Gorivo: diesel. 
Snaga motora: 45 kW. 
Radni obujam: 799 cm3. 
Mjenjač: automatski. 
Stanje: rabljeno.
Ostalo: Uredno servisiran i garažiran.
', 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/2002_Smart_Fortwo_Pure_CDi_800cc_Front.jpg/800px-2002_Smart_Fortwo_Pure_CDi_800cc_Front.jpg?20181213174923', 25000),
(6, 2, 3, 'IPHONE 13', 'Opširnije: IPHONE 13 512GB,CRNI MODEL, NOVO.', 
'https://www.links.hr/content/images/thumbs/011/0112809_smartphone-apple-iphone-13-61-128gb-crni.jpg', 8000),
(7, 2, 3, 'IPHONE 13 PRO', 'Opširnije: IPHONE 13 PRO 256GB, BIJELI MODEL, NOVO.', 
'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-13-pro-max-silver-select?wid=940&hei=1112&fmt=png-alpha&.v=1645552346280', 10000),
(8, 2, 3, 'SAMSUNG GALAXY S10', 'Opširnije: SAMSUNG GALAXY S10 64GB, CRNI MODEL, ONYX, NOVO.', 
'https://www.nabava.net/slike/products/53/90/15239053/samsung-galaxy-s10-rabljeno-128gb_8c0c858c.jpeg', 5000),
(9, 2, 3, 'SAMSUNG GALAXY S22', 'Opširnije: SAMSUNG GALAXY S22 512 GB, MODEL ARCTIC SILVER, NOVO.', 
'https://cdn.chipoteka.hr/image/cache/catalog/products160153-1063/smartphone-samsung-galaxy-s22-61-8gb256gb-crni-AP1OH4OUB-1155x1155.jpg', 7500),
(10, 3, 3, 'ROLEX DEEP SEA DWELER', 'Opširnije: DEEP SEA DWELER, muški sat, safirno staklo, ETA SWISS mehanizam, podešavajuća narukvica, SLIP GRADE, NOVO.', 
'https://m.media-amazon.com/images/I/61ZsARQ8wlL._AC_UY879_.jpg', 70000);

INSERT INTO `ponuda` (`ponuda_id`, `predmet_id`, `korisnik_id`, `datum_vrijeme_ponude`, `iznos_ponude`) VALUES
(1, 1, 10, '2022-07-04 15:15:00', 401000),
(2, 2, 11, '2022-07-05 10:25:00', 173000),
(3, 3, 12, '2022-07-05 12:35:00', 90500),
(4, 4, 13, '2022-07-06 16:45:00', 72000),
(5, 5, 14, '2022-07-06 17:55:00', 26000),
(6, 1, 15, '2022-07-07 09:15:00', 403000),
(7, 2, 16, '2022-07-07 10:25:00', 180000),
(8, 3, 17, '2022-07-07 20:35:00', 92000),
(9, 4, 19, '2022-07-07 21:45:00', 75000),
(10, 5, 20, '2022-07-07 22:55:00', 28000),
(11, 4, 21, '2022-07-08 23:45:00', 77500),
(12, 3, 3, '2022-07-08 23:50:00', 95000),
(13, 1, 10, '2022-07-08 23:54:10', 420000),
(14, 1, 15, '2022-07-08 23:54:30', 450000),
(15, 6, 10, '2022-07-09 17:10:00', 8100),
(16, 7, 11, '2022-07-10 18:20:00', 10200),
(17, 8, 12, '2022-07-10 19:30:00', 5200),
(18, 9, 13, '2022-07-10 20:40:00', 7650),
(19, 6, 14, '2022-07-11 08:50:00', 8200),
(20, 7, 15, '2022-07-11 09:10:00', 11000),
(21, 10, 4, '2022-07-11 11:30:00', 80000);