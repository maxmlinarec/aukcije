CREATE SCHEMA IF NOT EXISTS `aukcija` DEFAULT CHARACTER SET utf8 ;
USE `aukcija` ;

CREATE TABLE IF NOT EXISTS `aukcija`.`tip_korisnika` (
  `tip_id` INT(10) NOT NULL AUTO_INCREMENT,
  `naziv` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`tip_id`))
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `aukcija`.`korisnik` (
  `korisnik_id` INT(10) NOT NULL AUTO_INCREMENT,
  `tip_id` INT(10) NOT NULL,
  `korisnicko_ime` VARCHAR(50) NOT NULL,
  `lozinka` VARCHAR(50) NOT NULL,
  `ime` VARCHAR(50) NOT NULL,
  `prezime` VARCHAR(50) NOT NULL,
  `email` VARCHAR(50) NULL,
  `slika` VARCHAR(100) NULL,
  PRIMARY KEY (`korisnik_id`),
  INDEX `fk_korisnik_tip_korisnika_idx` (`tip_id` ASC),
  CONSTRAINT `fk_korisnik_tip_korisnika`
    FOREIGN KEY (`tip_id`)
    REFERENCES `aukcija`.`tip_korisnika` (`tip_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `aukcija`.`aukcija` (
  `aukcija_id` INT(10) NOT NULL AUTO_INCREMENT,
  `moderator_id` INT(10) NOT NULL,
  `naziv` VARCHAR(50) NOT NULL,
  `opis` VARCHAR(100) NOT NULL,
  `datum_vrijeme_pocetka` DATETIME NOT NULL,
  `datum_vrijeme_zavrsetka` DATETIME NULL,
  PRIMARY KEY (`aukcija_id`),
  INDEX `fk_kateogrija_predmeta_korisnik1_idx` (`moderator_id` ASC),
  CONSTRAINT `fk_kateogrija_predmeta_korisnik1`
    FOREIGN KEY (`moderator_id`)
    REFERENCES `aukcija`.`korisnik` (`korisnik_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `aukcija`.`predmet` (
  `predmet_id` INT(10) NOT NULL AUTO_INCREMENT,
  `aukcija_id` INT(10) NOT NULL,
  `korisnik_id` INT(10) NOT NULL,
  `naziv` VARCHAR(50) NOT NULL,
  `opis` TEXT NOT NULL,
  `slika` TEXT NOT NULL,
  `pocetna_cijena` FLOAT(10) NOT NULL,
  PRIMARY KEY (`predmet_id`),
  INDEX `fk_predmet_aukcija1_idx` (`aukcija_id` ASC),
  INDEX `fk_predmet_korisnik1_idx` (`korisnik_id` ASC),
  CONSTRAINT `fk_predmet_aukcija1`
    FOREIGN KEY (`aukcija_id`)
    REFERENCES `aukcija`.`aukcija` (`aukcija_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_predmet_korisnik1`
    FOREIGN KEY (`korisnik_id`)
    REFERENCES `aukcija`.`korisnik` (`korisnik_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `aukcija`.`ponuda` (
  `ponuda_id` INT(10) NOT NULL AUTO_INCREMENT,
  `predmet_id` INT(10) NOT NULL,
  `korisnik_id` INT(10) NOT NULL,
  `datum_vrijeme_ponude` DATETIME NOT NULL,
  `iznos_ponude` FLOAT(10) NULL,
  INDEX `fk_predmet_has_korisnik_korisnik1_idx` (`korisnik_id` ASC),
  INDEX `fk_predmet_has_korisnik_predmet1_idx` (`predmet_id` ASC),
  PRIMARY KEY (`ponuda_id`),
  CONSTRAINT `fk_predmet_has_korisnik_predmet1`
    FOREIGN KEY (`predmet_id`)
    REFERENCES `aukcija`.`predmet` (`predmet_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_predmet_has_korisnik_korisnik1`
    FOREIGN KEY (`korisnik_id`)
    REFERENCES `aukcija`.`korisnik` (`korisnik_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;
