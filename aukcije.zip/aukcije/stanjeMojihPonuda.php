<section>
    <h2>Stanje mojih ponuda na otvorenim aukcijama:</h2>

    <table>
        <?php showStanjeMojihPonuda($con,$_SESSION["korisnik_id"])?>
    </table>
</section>