<?php
include_once 'auth.php';
include_once 'common.php';
include_once 'aukcijaData.php';
include_once 'korisnikData.php';
include_once  'predmetData.php';

checkInputParams([
    'id' => 'integer'
]);

?>
<html>
<head>
    <link type="text/css" rel="stylesheet" charset="UTF-8" href="style.css">
</head>
<body>
<div class="content">
    <?php 
        include 'nav.php';
        $aukc = getMojeAukcije($con,$_GET['id']);
    ?>

   <?php if(isAdmin()) include 'urediAukcijeFormA.php'?>
    <?php if(isVoditelj()) include 'urediAukcijeFormM.php'?>

   
</div>

</body>
</html>
