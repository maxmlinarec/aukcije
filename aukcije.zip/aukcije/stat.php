<?php
include 'auth.php';
include 'statData.php';
include 'common.php';

if (!isAdmin()){
	redirectToIndex();
}

$dv_p = null;
$dv_z = null;

if (isset($_GET['datum_p']) && isset($_GET['vrijeme_p']) && isset($_GET['datum_z']) && isset($_GET['vrijeme_z'])){
	$d_p = $_GET['datum_p']; $v_p = $_GET['vrijeme_p'];
	$d_z = $_GET['datum_z']; $v_z = $_GET['vrijeme_z'];
	
	$dv_p = datumVrijeme($d_p, $v_p);
	$dv_z = datumVrijeme($d_z, $v_z);
}else{
	$d_p = '';
	$v_p = '';
	$d_z = '';
	$v_z = '';
}
?>
<html>
<head>
    <link type="text/css" rel="stylesheet" charset="UTF-8" href="style.css">
</head>
<body>
<div class="content">
    <?php include 'nav.php';?>
<form method="GET" >
	<h3>Zadaj interval (baziran na početku vremena aukcije)</h3>
	<label>Početni datum intervala </label>
	<input type="text" name="datum_p" placeholder="dd.mm.gggg" required value="<?php echo $d_p; ?>">
	<label>Početno vrijeme intervala </label>
	<input type="text" name="vrijeme_p" placeholder="hh:mm:ss" required value="<?php echo $v_p; ?>">
	<label>Završni datum intervala </label>
	<input type="text" name="datum_z" placeholder="dd.mm.gggg" required value="<?php echo $d_z; ?>">
	<label>Završno vrijeme intervala </label>
	<input type="text" name="vrijeme_z" placeholder="hh:mm:ss" required value="<?php echo $v_z; ?>">
	<button type="submit" class="a">Pogledaj</button>
</form>


<?php
if ($dv_z !== null || $dv_p !== null){

if (!$dv_p || !$dv_z){
	echo "Pogrešno zadani vremenski intervali";	
}else{
	showStats($con,$dv_p,$dv_z);
}
}
?>
</div>

</body>
</html>
