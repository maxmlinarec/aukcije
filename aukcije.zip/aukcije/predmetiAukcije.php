<?php
include 'auth.php';
include 'predmetData.php';
include 'common.php';
include 'aukcijaData.php';

checkInputParams([
    'id' => 'integer'
]);

$aukcija = getAukcija($con, $_GET['id']);


if ($aukcija === null){
    redirectToIndex('Aukcija ne postoji');
}

?>

<html>
<head>
    <link type="text/css" rel="stylesheet" charset="UTF-8" href="style.css">
</head>
<body>
<div class="content">
    <?php include 'nav.php'; ?>
    <?php 
        if(isSessionSet()){
            echo '<a href="addAukcija.php?id='.$_GET['id'].'" class="a">Dodaj novi predmet</a>';
        } 
    ?>
    <section>
        <h2><?php echo 'Aukcija ' . $aukcija['naziv'] . ' - Predmeti'; ?></h2>
        <table>
            <?php showPredmetiAukcijeById($con, $_GET['id']); ?>
        </table>
    </section>
</div>
</body>
</html>
