<section>
    <h2>Moje zatvorene aukcije:</h2>

    <table>
        <?php showMojeZatvAukcije($con,$_SESSION["korisnik_id"])?>
    </table>
</section>